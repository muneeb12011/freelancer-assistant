// src/App.jsx
// ─────────────────────────────────────────────
//  Updated App with:
//  - AuthProvider wrapping everything
//  - /login and /register routes (public)
//  - All app routes wrapped in <ProtectedRoute>
//    so they redirect to /login if not logged in
// ─────────────────────────────────────────────

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Auth system
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';

// Auth page
import Auth from './pages/Auth';

// Layout (Navbar + Sidebar wrapper)
import Layout from './components/Layout';

// App pages
import Dashboard   from './pages/Dashboard';
import Tasks       from './pages/Tasks';
import Clients     from './pages/Clients';
import Profile     from './pages/Profile';
import Invoices    from './pages/Invoices';
import Settings    from './pages/Settings';
import Support     from './pages/Support';
import Connections from './pages/Connections';
import Atelier     from './pages/Atelier';
import Home        from './pages/Home';
import About       from './pages/About';
import Contact     from './pages/Contact';

import './styles/App.css';

const App = () => {
  return (
    // AuthProvider must wrap everything so useAuth() works app-wide
    <AuthProvider>
      <Router>
        <Routes>

          {/* ── Public auth routes ─────────────────
              These pages do NOT require login.
              /login and /register both render <Auth />
              which handles the mode toggle internally.
          ─────────────────────────────────────── */}
          <Route path="/login"    element={<Auth />} />
          <Route path="/register" element={<Auth />} />

          {/* ── Protected app routes ───────────────
              Everything inside <ProtectedRoute> will
              redirect to /login if the user is not
              authenticated.
          ─────────────────────────────────────── */}
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            {/* Default page when visiting "/" */}
            <Route index element={<Home />} />

            {/* Public-feeling marketing pages (still inside app) */}
            <Route path="about"   element={<About />} />
            <Route path="contact" element={<Contact />} />

            {/* Core app routes */}
            <Route path="dashboard"   element={<Dashboard />} />
            <Route path="tasks"       element={<Tasks />} />
            <Route path="clients"     element={<Clients />} />
            <Route path="profile"     element={<Profile />} />
            <Route path="invoices"    element={<Invoices />} />
            <Route path="settings"    element={<Settings />} />
            <Route path="support"     element={<Support />} />
            <Route path="connections" element={<Connections />} />
            <Route path="create-task" element={<Atelier />} />
          </Route>

          {/* ── Catch-all 404 → redirect to home ── */}
          <Route path="*" element={<Navigate to="/" replace />} />

        </Routes>
      </Router>
    </AuthProvider>
  );
};

export default App;